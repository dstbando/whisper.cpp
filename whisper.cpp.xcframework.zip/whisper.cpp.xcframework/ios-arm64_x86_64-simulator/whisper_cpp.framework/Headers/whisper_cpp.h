//
//  whisper_cpp.h
//  whisper.cpp
//
//  Created by Takashi Bando on 3/12/24.
//

#import <Foundation/Foundation.h>

//! Project version number for whisper_cpp.
FOUNDATION_EXPORT double whisper_cppVersionNumber;

//! Project version string for whisper_cpp.
FOUNDATION_EXPORT const unsigned char whisper_cppVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <whisper_cpp/PublicHeader.h>

#import <whisper_cpp/ggml.h>
#import <whisper_cpp/whisper.h>
